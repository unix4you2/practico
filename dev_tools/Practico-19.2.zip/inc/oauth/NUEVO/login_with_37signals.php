<?php
/*
 * login_with_basecamp.php
 *
 * @(#) $Id: login_with_37signals.php,v 1.1 2014/03/17 09:45:08 mlemos Exp $
 *
 */

	/*
	 *  Get the http.php file from http://www.phpclasses.org/httpclient
	 */
	require('http.php');
	require('oauth_client.php');

	$client = new oauth_client_class;
	$client->server = '37Signals';
	$client->debug = false;
	$client->debug_http = true;
	$client->redirect_uri = 'http://'.$_SERVER['HTTP_HOST'].
		dirname(strtok($_SERVER['REQUEST_URI'],'?')).'/login_with_37signals.php';

	$client->client_id = ''; $application_line = __LINE__;
	$client->client_secret = '';

	// 37Signals
	$client->client_id = '68a354455ac2e3dacbce2f3ae5fd3fd018869e95';
	$client->client_secret = '4a4be253ce94b861a1829db946120be48b2563fe';

	if(strlen($client->client_id) == 0
	|| strlen($client->client_secret) == 0)
		die('Please go to 37Signals Integrate new application page '.
			'https://integrate.37signals.com/apps/new and in the line '.$application_line.
			' set the client_id to Client ID and client_secret with Client secret. '.
			'The site domain must have the same domain of '.$client->redirect_uri);

	/* API permissions
	 */
	$client->scope = '';
	if(($success = $client->Initialize()))
	{
		if(($success = $client->Process()))
		{
			if(strlen($client->authorization_error))
			{
				$client->error = $client->authorization_error;
				$success = false;
			}
			elseif(strlen($client->access_token))
			{
				$success = $client->CallAPI(
					'https://launchpad.37signals.com/authorization.json',
					'GET', array(), array('FailOnAccessError'=>true), $user);
			}
		}
		$success = $client->Finalize($success);
	}
	if($client->exit)
		exit;
	if($success)
	{
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>37Signals OAuth client results</title>
</head>
<body>
<?php
		echo '<h1>', HtmlSpecialChars($user->identity->first_name),
			' you have logged in successfully with 37Signals!</h1>';
		echo '<pre>', HtmlSpecialChars(print_r($user, 1)), '</pre>';
?>
</body>
</html>
<?php
	}
	else
	{
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>OAuth client error</title>
</head>
<body>
<h1>OAuth client error</h1>
<pre>Error: <?php echo HtmlSpecialChars($client->error); ?></pre>
</body>
</html>
<?php
	}

?>