ace.define("ace/snippets/forth",["require","exports","module"],function(e,t,n){"use strict";t.snippetText=undefined,t.scope="forth"});                (function() {
                    ace.require(["ace/snippets/forth"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            