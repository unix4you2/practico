ace.define("ace/snippets/scad",["require","exports","module"],function(e,t,n){"use strict";t.snippetText=undefined,t.scope="scad"});                (function() {
                    ace.require(["ace/snippets/scad"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            